package com.galaxcy.protego;

/**
 * Created by Andreas on 29/04/2017.
 */

import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.GroundOverlay;
import com.google.android.gms.maps.model.GroundOverlayOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class ViewFires extends Fragment implements OnMapReadyCallback {
    private GoogleMap mMap;

    int numCircles=0;
    GroundOverlay[] circleOverlay = new GroundOverlay[10];
    DatabaseReference mRootRef= FirebaseDatabase.getInstance().getReference();
    DatabaseReference mConditionRef= mRootRef.child("condition");

    /** FUNCTION FOR ACCESSING FIREBASE DATABASE**/
    @Override
    public void onStart(){
        super.onStart();
        mConditionRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String text = dataSnapshot.getValue(String.class);
                Toast.makeText(getContext(),String.valueOf(text), Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.view_fires, container, false);
       /**CREATES A HARDCODED PATH ON THE MAP. ACTUAL ALGORITHM IS NECESSARY FOR FULL IMPLEMENTATION **/
        Button btnFindPath = (Button) rootView.findViewById(R.id.btnFindPath);
        btnFindPath.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Polyline line2 = mMap.addPolyline(new PolylineOptions()
                        .add(new LatLng(35.0208,32.3295), new LatLng(35.0203,32.3298), new LatLng(35.0199,32.3303), new LatLng(35.0197,32.3309), new LatLng(35.0189,32.3316),
                                new LatLng(35.0176, 32.3335), new LatLng(35.0165, 32.3342), new LatLng(35.0161,32.3343), new LatLng(35.0155, 32.3349), new LatLng(35.0152, 32.3351),
                                new LatLng(35.0150, 32.3349), new LatLng(35.0141, 32.3349), new LatLng(35.0117, 32.3359), new LatLng(35.0112, 32.3361), new LatLng(35.0103, 32.3369),
                                new LatLng(35.0103, 32.3372), new LatLng(35.0105, 32.3374), new LatLng(35.0107, 32.3378), new LatLng(35.0102, 32.3383), new LatLng(35.0099, 32.3384))

                        .width(5)
                        .color(Color.RED));
            }
        });
        Button btnLegend = (Button) rootView.findViewById(R.id.btnLegend);
        btnLegend.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
         new AlertDialog.Builder(getContext())
                       .setTitle("Map Legend: ")
                .setMessage("GREEN- ALL OK \n YELLOW-PROTEGO ON STANDBY \nGREY- SMOKE\n RED- HIGH TEMPERATURE/FIRE \nDARK RED- KAMIKAZE\n PURPLE- MODIS DATA \n BLUE-USER REPORTS")

                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener(){
                            public void onClick(DialogInterface dialog, int which){

                            }
                        }).show();
            }
        });
        /** POPUP FOR SOS REPORT. THIS REPORT MUST BE SENT TO THE FIREBASE**/
        Button btnSOS = (Button) rootView.findViewById(R.id.btnSOS);
        btnSOS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    new AlertDialog.Builder(getContext())
                            .setTitle("SOS SENT!")
                            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    new AlertDialog.Builder(getContext())
                                            .setTitle("CALL A MEDIC?")
                                            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {

                                                }
                                            })
                                            .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {

                                                }
                                            }).show();
                                }
                            })
                            .show();
            }
        });

        /**CREATES A HARDCODED PATH. ACTUAL ALGORITHM IS NECESSARY**/
        Button btnNavPath= (Button) rootView.findViewById(R.id.btnNavPath);
        btnNavPath.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                LatLng currentLoc = createLocation(35.035590, 32.352066);
                Polyline line = mMap.addPolyline(new PolylineOptions()
                        .add(currentLoc, new LatLng(35.033561, 32.355325), new LatLng(35.031050, 32.353691),
                        new LatLng(35.030805, 32.353416), new LatLng(35.030364, 32.354518), new LatLng(35.028704, 32.355599), new LatLng(35.028496, 32.355683), new LatLng(35.027849, 32.356519),
                                new LatLng(35.026910, 32.357252), new LatLng(35.025521, 32.359834), new LatLng(35.024999, 32.360023), new LatLng(35.025394, 32.350306), new LatLng(35.023149, 32.347363),
                                new LatLng(35.024105, 32.340685), new LatLng(35.022995, 32.338666), new LatLng(35.023876, 32.334608), new LatLng(35.023257, 32.328923), new LatLng(35.027175, 32.325934))
                        .width(5)
                        .color(Color.RED));

            }
        });

        /**CHANGE THE VIEW MODE OF THE MAP. CONTOUR IS ALSO POSSIBLE **/
        Button btnChangeView = (Button) rootView.findViewById(R.id.btnChangeView);
        btnChangeView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
            }
        });

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager()
                .findFragmentById(R.id.map);

        mapFragment.getMapAsync(this);
        Spinner spin = (Spinner) rootView.findViewById(R.id.spinnerSelectOverlay);
        List<String> dropdown = new ArrayList<String>();

        dropdown.add("View fires from Protego");
        dropdown.add("View fires from MODIS satellite");
        dropdown.add("View fires from VIIRS satellite");
        dropdown.add("View reported fires");
        dropdown.add("View landslides and flooded areas");


        ArrayAdapter<String> dataAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_dropdown_item, dropdown);
        spin.setAdapter(dataAdapter);


        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                Log.v("item", String.valueOf(position));
                switch (position) {
                    //Protego data
                    case 0:
                        /**Clear the map, then add the watchtower images, then add the Protego data **/
                        mMap.clear();
                        List<Double> latList2 = new ArrayList<java.lang.Double>();
                        java.lang.Double[] latArray2 = scanLatLong(latList2, getResources().openRawResource(R.raw.firestop));
                        List<Double> longList2 = new ArrayList<java.lang.Double>();
                        java.lang.Double[] longArray2 = scanLatLong(longList2, getResources().openRawResource(R.raw.firestopy));
                        for (int i = 0; i < latArray2.length; i++) {
                            mMap.addMarker(new MarkerOptions().position(createLocation(latArray2[i], longArray2[i]))
                                    .icon(BitmapDescriptorFactory.fromResource(R.mipmap.watchtower)));
                        }
                        latLngToMap(getResources().openRawResource(R.raw.x_0), getResources().openRawResource(R.raw.y_0),100, "#666DC066", "0.1", true);
                        latLngToMap(getResources().openRawResource(R.raw.x_1), getResources().openRawResource(R.raw.y_1),100, "#66ffff7f", "0.2", true);
                        latLngToMap(getResources().openRawResource(R.raw.x_2), getResources().openRawResource(R.raw.y_2),100, "#667a8b7f", "0.3", true);
                        latLngToMap(getResources().openRawResource(R.raw.x_3), getResources().openRawResource(R.raw.y_3),100, "#66e90510", "0.4", true);
                        latLngToMap(getResources().openRawResource(R.raw.x_4), getResources().openRawResource(R.raw.y_4),100, "#66AB0606", "0.5", true);

                        break;

                    //MODIS DATA
                    case 1:
                        /**Clear the map. Then update the camera position, then add the watchtower images, then add the MODIS data **/
                        mMap.clear();

                        CameraUpdate camPos1 = CameraUpdateFactory.newLatLngZoom(createLocation(34.987645, 32.966200), 12);
                        mMap.moveCamera(camPos1);
                        mMap.animateCamera(camPos1);

                        List<Double> latList = new ArrayList<java.lang.Double>();
                        java.lang.Double[] latArray = scanLatLong(latList, getResources().openRawResource(R.raw.firestop));
                        List<Double> longList = new ArrayList<java.lang.Double>();
                        java.lang.Double[] longArray = scanLatLong(longList, getResources().openRawResource(R.raw.firestopy));
                        for (int i = 0; i < latArray.length; i++) {
                            mMap.addMarker(new MarkerOptions().position(createLocation(latArray[i], longArray[i]))
                                    .icon(BitmapDescriptorFactory.fromResource(R.mipmap.watchtower)));
                        }
                        latLngToMap(getResources().openRawResource(R.raw.latitude_vertic), getResources().openRawResource(R.raw.longitude_horiz), 200, "#66800080", "0.1", true);

                        break;

                    //VIIRS DATA
                    case 2:
                        /**Clear the map. Then update the camera position, then add the watchtower images, then add the VIIRS data **/
                        mMap.clear();

                        CameraUpdate camPos2 = CameraUpdateFactory.newLatLngZoom(createLocation(34.731816, 33.335985), 12);
                        mMap.moveCamera(camPos2);
                        mMap.animateCamera(camPos2);

                        List<Double> latList4 = new ArrayList<java.lang.Double>();
                        java.lang.Double[] latArray4 = scanLatLong(latList4, getResources().openRawResource(R.raw.firestop));
                        List<Double> longList4 = new ArrayList<java.lang.Double>();
                        java.lang.Double[] longArray4 = scanLatLong(longList4, getResources().openRawResource(R.raw.firestopy));
                        for (int i=0; i<latArray4.length;i++){
                            mMap.addMarker(new MarkerOptions() .position(createLocation(latArray4[i], longArray4[i]))
                                    .icon(BitmapDescriptorFactory.fromResource(R.mipmap.watchtower)));
                        }
                        latLngToMap(getResources().openRawResource(R.raw.x_glob), getResources().openRawResource(R.raw.y_glob), 200, "#66800080", "0.1", true);

                        break;

                    //REPORTED DATA
                    case 3:
                        /**clear the map. Then update the camera position, then add the watchtower images, then add the reported data **/
                        mMap.clear();

                        CameraUpdate camPos3 = CameraUpdateFactory.newLatLngZoom(createLocation(35.035590, 32.352066), 12);
                        mMap.moveCamera(camPos3);
                        mMap.animateCamera(camPos3);

                        List<Double> latList3 = new ArrayList<java.lang.Double>();
                        java.lang.Double[] latArray3 = scanLatLong(latList3, getResources().openRawResource(R.raw.firestop));
                        List<Double> longList3 = new ArrayList<java.lang.Double>();
                        java.lang.Double[] longArray3 = scanLatLong(longList3, getResources().openRawResource(R.raw.firestopy));
                        for (int i=0; i<latArray3.length;i++){
                            mMap.addMarker(new MarkerOptions() .position(createLocation(latArray3[i],longArray3[i] ))
                                    .icon(BitmapDescriptorFactory.fromResource(R.mipmap.watchtower)));
                        }
                        latLngToMap(getResources().openRawResource(R.raw.fory), getResources().openRawResource(R.raw.forx),400, "#660000FF", "0.1", true);

                        break;

                    //LANDSLIDES AND FLOODED AREAS
                    case 4:
                        /**clear the map. Then update the camera position, then add the watchtower images,
                         *  then add the flood hazard images, then add the landslide images **/
                        mMap.clear();

                        CameraUpdate camPos4 = CameraUpdateFactory.newLatLngZoom(createLocation(34.809311, 32.861731), 9);
                        mMap.moveCamera(camPos4);
                        mMap.animateCamera(camPos4);

                        List<Double> latList5 = new ArrayList<java.lang.Double>();
                        java.lang.Double[] latArray5 = scanLatLong(latList5, getResources().openRawResource(R.raw.firestop));
                        List<Double> longList5 = new ArrayList<java.lang.Double>();
                        java.lang.Double[] longArray5 =  scanLatLong(longList5, getResources().openRawResource(R.raw.firestopy));
                        for (int i=0; i<latArray5.length;i++){
                            mMap.addMarker(new MarkerOptions() .position(createLocation(latArray5[i], longArray5[i]))
                            .icon(BitmapDescriptorFactory.fromResource(R.mipmap.watchtower)));

                        }
                        List<Double> latList6 = new ArrayList<java.lang.Double>();
                        java.lang.Double[] latArray6 = scanLatLong(latList6, getResources().openRawResource(R.raw.x));
                        List<Double> longList6 = new ArrayList<java.lang.Double>();
                        java.lang.Double[] longArray6 = scanLatLong(longList6, getResources().openRawResource(R.raw.y));
                        for (int i = 0; i<latArray6.length;i++){
                            mMap.addMarker(new MarkerOptions() .position(createLocation(latArray6[i], longArray6[i]))
                            .icon(BitmapDescriptorFactory.fromResource(R.mipmap.hazardwarning)));
                        }

                        List<Double> latList7 = new ArrayList<java.lang.Double>();
                        java.lang.Double[] latArray7 = scanLatLong(latList7, getResources().openRawResource(R.raw.x_));
                        List<Double> longList7 = new ArrayList<java.lang.Double>();
                        java.lang.Double[] longArray7 = scanLatLong(longList7, getResources().openRawResource(R.raw.y_));
                        for(int i=0; i<latArray7.length;i++){
                            mMap.addMarker(new MarkerOptions() .position(createLocation(latArray7[i], longArray7[i]))
                            .icon(BitmapDescriptorFactory.fromResource(R.mipmap.landslide)));
                        }
                        break;

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });
        return rootView;
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        /**when the map is ready to be shown on screen, first move the camera into a suitable position, then check the permissions**/
        mMap = googleMap;
        LatLng curLoc = createLocation(35.0208,32.3295);
        CameraUpdate cameraPosition = CameraUpdateFactory.newLatLngZoom(curLoc, 14);
            mMap.moveCamera(cameraPosition);
            mMap.animateCamera(cameraPosition);

        //PERMISSIONS CHECK
        if (ActivityCompat.checkSelfPermission(getContext(), android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getContext(),
                android.Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(),
                    new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION,
                            android.Manifest.permission.ACCESS_FINE_LOCATION}, 99);

        } else {

        }
        mMap.setMyLocationEnabled(true);

           /*METHOD FOR EXTERNAL STORAGE OF CSV*/
        //Scanner scanLat, scanLong;
        //String latFile="latitude_vertic.csv";
        //File longFile = new File("/storage/emulated/0/longitude_horiz.csv");
        //List<java.lang.Double> longList = new ArrayList<java.lang.Double>();
        //java.lang.Double[] longArray = scanLatLong((longList),longFile);
        //String longFile="/res/longitude_horiz.csv";

        /**METHOD FOR INTERNAL CSV STORAGE**/
    }

    /**Clean up by destroying the map fragment...Crashes app if left in memory**/
    @Override
    public void onDestroyView() {

        super.onDestroyView();
        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null)
            getChildFragmentManager().beginTransaction().remove(mapFragment).commitAllowingStateLoss();
    }

    /**
     * Function takes two double values and creates a LatLng object with them
     **/
    private LatLng createLocation(double lat, double lon) {
        LatLng latlng = new LatLng(lat, lon);
        return latlng;
    }

    /***
     * Function reads the latitude and longitude from the files, and the array it should be placed in, and returns the populated array
     ***/
    private java.lang.Double[] scanLatLong(List<java.lang.Double> latLongArray, InputStream file) {
      /*METHOD1 USING EXTERNAL STORAGE*/
        //  try {
        //Scanner scanLatLong = new Scanner(file);
        //scanLatLong.useDelimiter(",");

//            while(scanLatLong.hasNextDouble()){
        //              latLongArray.add( Double.parseDouble(scanLatLong.next()) );
        //        }
        //      scanLatLong.close();

        //}catch(FileNotFoundException e){Log.d("failure", "Failed "+file);}
        //return latLongArray.toArray(new java.lang.Double[latLongArray.size()]);

            /*METHOD 2 USING INTERNAL STORAGE*/
        InputStreamReader isr = new InputStreamReader(file);
        BufferedReader buffer = new BufferedReader(isr);
        try {
            String read = "";

            while ((read = buffer.readLine()) != null) {

                for (int j = 0; j < read.split(",").length; j++) {
                    latLongArray.add(Double.parseDouble(read.split(",")[j]));
                }
            }
            buffer.close();

        } catch (IOException ioe) {
            Log.d("failure", "failed IO " + file);
        }
        return latLongArray.toArray(new java.lang.Double[latLongArray.size()]);
    }

    /***
     * Function takes file input streams of X & Y value files, and the color needed, and draws it onto the map
     ***/
    private void latLngToMap(InputStream iStreamLat, InputStream iStreamLong, int rad, String color, String zInd, boolean vis) {
        List<Double> latList = new ArrayList<java.lang.Double>();
        java.lang.Double[] latArray = scanLatLong(latList, iStreamLat);
        List<Double> longList = new ArrayList<java.lang.Double>();
        java.lang.Double[] longArray = scanLatLong(longList, iStreamLong);

        /**Create circle**/
        for (int i = 0; i < latArray.length; i++) {
            mMap.addCircle(new CircleOptions().center(createLocation(latArray[i],
                    longArray[i])).radius(rad).strokeColor(Color.parseColor(color)).fillColor(Color.parseColor(color)).zIndex(Float.parseFloat(zInd)).visible(vis));
        }
    }

    /**Used for blinking the circles ---WARNING HIGHLY RAM INTENSIVE. NEEDS OPTIMISATION---**/
    private void latLngToMap2(InputStream iStreamLat, InputStream iStreamLong, String color) {
        List<Double> latList = new ArrayList<java.lang.Double>();
        java.lang.Double[] latArray = scanLatLong(latList, iStreamLat);
        List<Double> longList = new ArrayList<java.lang.Double>();
        java.lang.Double[] longArray = scanLatLong(longList, iStreamLong);

        //Create a drawable, convert it to a bitmap, and then draw it
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setSize(500,500);
        d.setColor(Color.parseColor(color));
        d.setStroke(5, Color.TRANSPARENT);

        Bitmap bitmap = Bitmap.createBitmap(d.getIntrinsicWidth()
                , d.getIntrinsicHeight()
                , Bitmap.Config.ARGB_8888);


        Canvas canvas = new Canvas(bitmap);
        d.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        d.draw(canvas);

        // Add the circle to the map
        for (int i=0;i<latArray.length; i++) {
            circleOverlay[i] = mMap.addGroundOverlay(new GroundOverlayOptions()
                    .position(createLocation(latArray[i], longArray[i]),250).image(BitmapDescriptorFactory.fromBitmap(bitmap)));
            numCircles++;
        }

    }

    /** HIGHLY RAM INTENSIVE FUNCTION USED TO BLINK THE CIRCLES. DO NOT USE ON A LESS MODERN PHONE**/
    private void blink(){
        final Handler h = new Handler();
        h.postDelayed(new Runnable() {
            public void run() {

                circleOverlay[0].remove();
                circleOverlay[1].remove();
                circleOverlay[2].remove();
                latLngToMap2(getResources().openRawResource(R.raw.x_3), getResources().openRawResource(R.raw.y_3), "#66e90510");

                h.postDelayed(this, 10);
            }
        }, 25);

    }

}




