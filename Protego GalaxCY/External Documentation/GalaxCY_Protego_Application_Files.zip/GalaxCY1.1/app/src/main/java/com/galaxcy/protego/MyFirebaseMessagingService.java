package com.galaxcy.protego;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.WindowManager;

import com.google.firebase.messaging.RemoteMessage;

/**
 * Created by Andreas on 03/05/2017.
 */

/**Application incorporates push notifications via Firebase. This class is necessary with FireBaseIDService.java**/


public class MyFirebaseMessagingService extends com.google.firebase.messaging.FirebaseMessagingService{

    private static final String TAG = "FCM Service";
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // TODO: Handle FCM messages here.

        Log.d(TAG, "From: " + remoteMessage.getFrom());
        Log.d(TAG, "Notification Message Body: " + remoteMessage.getNotification().getBody());
      final  String msg = remoteMessage.getFrom();


        new AlertDialog.Builder(MyFirebaseMessagingService.this)
                .setMessage( msg)
                .setCancelable(true)
                .create()
                .show();

    }




}